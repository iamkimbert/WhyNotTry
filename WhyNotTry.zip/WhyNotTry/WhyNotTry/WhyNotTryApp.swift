//
//  WhyNotTryApp.swift
//  WhyNotTry
//
//  Created by Kimberly Townsend on 3/28/24.
//

import SwiftUI

@main
struct WhyNotTryApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
